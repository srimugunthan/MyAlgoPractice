/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndixProb;

/**
 *
 * @author sdhandap
 */
abstract   public class PropositionEvaluator {
    
     public abstract boolean evaluate(int value);
}
