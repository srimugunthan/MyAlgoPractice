open index.html and click questions tab
