Hi All,
         I am going to write an article on how to approach High tech interviews from my experience. Before going through these, u have to understand that the ideas present here are totally mine and please do not scold me, if i provide anything wrong here. My major idea is to tell you how easy the interviews would be, if you follow the ideas present here. so that, if you start your preparation by now, you would be ready to crack the interviews in atmost 4 months time. Also you can save atleast a significant amount of time, on getting info about what to prepare and where is it. Also you dont have to be a above average student. This article is addressed for average or below average student like me. If u feel, u  know these things very well and you are above average student you can certainly skip quit reading this. My English may be horrible at some places, which you have to bear with me.

vacancies:
         You have to really understand that the vacancies in these companies are more, and increasing day by day. At any given time in a year, am 150% sure that all these companies have so many vacancies and they are dying to fill it up. But unfortunately they dont meet the expectations on what they are expecting from the interview.

           Also these people scan resume by college name at the first place. If you did your Engineering in one of top insitutuions in the state or country, then you can be sure that ur resume very well pass through 1st level shortlisting. Though Marks add value to your resume, its not prime concern. Anything above 70 % (CGPA 7) is enough for them.  

These kinda companies  mainly concentrate the following skills:
	1. Problem Solving ability (Puzzles)
	2. Good knowlege of Data structures and Algorithms
	3. Programming (either C,C++ or java)
	4. knowlege of OS (Not that important, enough to know concepts and famous os problems like producer-consumer etc)
Mention all these things under special interest of your resume.


Puzzles:
          First go through all old interview questions, try to solve it. Aftr that look out for answers. Always keep in touch with puzzle forums as many as you can. Try to solve puzzles whenever you feel bored. You will finally get an idea. U might be getting the same question in the interview or same type of questions most of the time (95%). So it would be easy for you, u would solve it in considerably low time. If you develop your logical thinking in solving puzzles, then you would be good in finding a good algorithm or logic when do coding also.

	some usefull links:
http://www.techinterview.org/ 
http://www.ocf.berkeley.edu/~wwu/riddles/intro.shtml
http://www.orkut.com/Community.aspx?cmm=20363 (orkut community)
http://www.orkut.com/Community.aspx?cmm=645 (orkut community)

Data structures and Algorithms:
	hmmm. All these companies look out for good knowledge of Data structures and algo. I would recommand everyone to go through "Introduction to Algorithms" by "Thomas cormen". I have a pdf version of that also. If u feel if the book is too lengthy to read, u can listen lectures of this book downloaded from

"http://ocw.mit.edu/OcwWeb/Electrical-Engineering-and-Computer-Science/6-046JFall-2005/LectureNotes/index.htm". After you went through these, u would finally get an idea on all data structures and its related operations also u would have a rough idea on complexity. All interviewers would expect you to write code which has least (time) complexity. Again, u should go through all old interview questions in Algorithms also. 

	some usefull links:
http://www.tekpool.com/
http://www.ocf.berkeley.edu/~wwu/riddles/intro.shtml
http://www.orkut.com/Community.aspx?cmm=22317 (orkut community)
http://www.orkut.com/Community.aspx?cmm=15828736 (orkut community)

Programming:
	You should know  c and c++. If u r nt interested in c and c++, java is the other option.
For C, i would recommand "Let us c" by kanetkar and "pointers in c" by the same author.
For C++, my favorite is "C++ complete reference" by "Herbert schildt", its enough to go thru c++ part alone of that book. I have pdf of this book.
By going through these, u would have refreshed all the things you learnt from college. 
Now the next thing is, i would recommend 2 sites, please go through inorder to get a deep understanding on these languages...

	some usefull links:
http://c-faq.com/
http://www.parashift.com/c++-faq-lite/

I have no idea for Java people.

People's Mentality:
            I seeing few people working with a particular technology or platform over a year, reluctant to change from those. I hear people saying like, "i have  experience in XYZ, (may be Language like c++ or java.., or technology like mainframes...) and i dont want to loose that by entering into another technology". This is really a bad idea. Unless you have 2+ yrs experience, you are treated as open. These companies expect u to work on any language or any platform. so please dont fix ur domain or technology and leave upto the interviewer. 

HR Interview:
             HR interview though not as important as tech interview, it is also important. In HR interview dont try be honest. Like if they ask whatz ur negative, if u honestly admit things, u would get 'S' grade for honesty but 'U' in the interview. Also abt ur +ve, dont try to think whatz ur positive. Ur positive would be nothing sensible or nothing realted to job. so interviewer is not interested in all these. 
I would recommand a document called "64 interview questions". Go through these word document. There are a couple of standard answers for all those questions. Select few of those answers from them and support your arguments by relating to a orginal story happend or frame a story by yourself :) All your points must have supporting arguments. HR interview as far as i know, a person who considers himself as a ideal person wins the HR interview (seems only frauds can win :) ).

Interview Materials:
              I am going to give u materials whatever v have used or  found useful. I going to split it as Level 1 and Level 2 in the  increasing order of difficulty.I shall upload those into our icsmit group. To get these files you have to sign-in to yahoo groups, click the files section on the left side.That will contain almost every interview question.If you go through all those and try findin answers, then u would be ready for the interview. If you dont know the answers, Just google . Its upto you to look out for other materials. Somewhere above, i have mentioned that i have pdf version of some books. U can demand me if you need that. I will try to email you.

Interview Process:
	When you feel your preparation in half way, u can post your resume in Naukri, Monster and TimesJob etc. Before posting, get verified ur resume with some one (i think ramasubu will help in this..). You will get calls from agent or company respective of your profile.  This will be a good option if you want to attend trial intervies and gain confidence. After you feel that you have enough confidence start attending interview for the companies you have in your mind. Sometimes you may fail the interview also. Do not loose confidence. Do R&D and find where you go wrong and find ways to correct the same. I am sure after 2 or 3 failure attempts, you are ready high confidence to crack the next one very easily. Also for Referal interviews, get in touch with your friends to refer you.

Join the following yahoo groups to get notification mails about the recruitment happening:
JobsForREC
bangalorejobs
Bangalore-Jobs_
JobJobs
Also there are various orkut communities which tells the same thing...

----------------------------------Good luck and All The Best-----------------------------------